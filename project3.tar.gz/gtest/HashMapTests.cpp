// HashMapTests.cpp
//
// ICS 45C Fall 2019
// Project #3: Maps and Legends
//
// Write unit tests for your HashMap class here.  I've provided a few tests
// already, though I've commented them out, because they won't compile and
// link until you've implemented some things.
//
// Of course, you'll want to write lots more of these tests yourself, because
// this is an inexpensive way to know whether things are working the way
// you expect -- including scenarios that you won't happen to hit in the
// course of testing your overall program.  (You might also want to be sure
// that your HashMap implementation is complete and correct before you try
// to write the rest of the program around it, anyway; there's a very
// substantial amount of partial credit available if all that works is
// HashMap.)

#include <gtest/gtest.h>
#include "HashMap.hpp"


TEST(HashMapTests, sizeOfNewlyCreatedHashMapIsZero){
   HashMap empty;
   ASSERT_EQ(0, empty.size());
}


TEST(HashMapTests, emptyMapContainsNoKeys){
   HashMap empty;
   ASSERT_FALSE(empty.contains("first"));
   ASSERT_FALSE(empty.contains("second"));
}


TEST(HashMapTests, containKeyAfterAddingIt){
   HashMap hm;
   hm.add("Boo", "perfect");
   ASSERT_TRUE(hm.contains("Boo"));
}

TEST(TestHashMap, NewHashMapIsTen){
    HashMap h;
    ASSERT_EQ(10, h.bucketCount());
}

TEST(TestHashMap, testCopy){
    HashMap h1;
    h1.add("tyrone", "123");
    h1.add("john", "234");
    h1.add("jaime", "345");


    HashMap h2 = h1;
    ASSERT_EQ(3, h2.size());
    ASSERT_EQ(true, h2.contains("tyrone"));
    ASSERT_EQ(true, h2.contains("john"));
    ASSERT_EQ(true, h2.contains("jaime"));
}

TEST(TestHashMap, testoperator){
    HashMap h1, h2;
    h1.add("kevin", "132");
    h1.add("derrick", "567");
    h1.add("hai", "789");
    h1.add("ho", "739");
    h2 = h1;
    ASSERT_EQ(4, h2.size());
    ASSERT_EQ(true, h2.contains("kevin"));
    ASSERT_EQ(true, h2.contains("derrick"));
    ASSERT_EQ(true, h2.contains("hai"));
    ASSERT_EQ(true, h2.contains("ho"));
}

TEST(TestHashMap, testAdd){
    HashMap h;
    h.add("boo", "123");
    ASSERT_EQ(true, h.contains("boo"));
    ASSERT_EQ("123", h.value("boo"));
    ASSERT_EQ(1, h.size());
}


TEST(TestHashMap, testRemove){
    HashMap h;
    h.add("boo", "123");
    h.add("alex", "234");
    h.add("john", "345");
    ASSERT_EQ(3, h.size());

    h.remove("boo");
    ASSERT_EQ(2, h.size());
    ASSERT_EQ(false, h.contains("boo"));
}

TEST(TestHashMap, testRemoveOfDoesntExist){
    HashMap h;
    h.add("boo", "123");
    h.add("alex", "234");
    h.add("john", "345");
    ASSERT_EQ(3, h.size());

    h.remove("john");
    ASSERT_EQ(2, h.size());
}

TEST(TestHashMap, testtwice){
    HashMap h;
    h.add("alex", "123");
    h.add("alex", "234");
    ASSERT_EQ("123", h.value("alex"));
}

TEST(TestHashMap, testRemovetwice){
    HashMap h;
    h.add("boo", "123");
    h.add("alex", "234");
    h.add("ben", "345");
    ASSERT_EQ(3, h.size());

    h.remove("boo");
    ASSERT_EQ(2, h.size());
    h.remove("boo");
    ASSERT_EQ(2, h.size());
    ASSERT_EQ(false, h.contains("boo"));
}

TEST(TestHashMap, testContains){
    HashMap h;
    h.add("boo", "123");
    h.add("alex", "234");
    h.add("ben", "345");
    
    ASSERT_EQ(true, h.contains("boo"));
    ASSERT_EQ(true, h.contains("alex"));
    ASSERT_EQ(true, h.contains("ben"));
}

TEST(TestHashMap, testValue){
    HashMap h;
    h.add("boo", "123");

    ASSERT_EQ("123", h.value("boo"));
}

TEST(TestHashMap, testValueOfNonExist){
    HashMap h;
    
    ASSERT_EQ("", h.value("alex"));
}

TEST(TestHashMap, testSize){
    HashMap h;
    h.add("boo", "123");
    ASSERT_EQ(1, h.size());

    h.add("alex", "234");
    ASSERT_EQ(2, h.size());
    
    h.add("ben", "345");
    ASSERT_EQ(3, h.size());

    h.remove("ben");
    ASSERT_EQ(2, h.size());

    h.remove("ben");
    ASSERT_EQ(2, h.size());
}

unsigned int func(const std::string& key){
	return key.length();
}

TEST(TestHashMap, testHashFunction){
	HashMap h = HashMap(func);
	h.add("tyrone","123");
	HashMap h2;
	h2 = h;

	ASSERT_EQ(1, h2.size());
}

TEST(TestHashMap, testBucketCount){
    HashMap h;
    ASSERT_EQ(10, h.bucketCount());
    
    h.add("tyrone", "123");
    h.add("john", "234");
    h.add("jaime", "345");
    h.add("james", "123");
    h.add("kevin", "132");
    h.add("derrick", "567");
    h.add("hai", "789");
    ASSERT_EQ(10, h.bucketCount());

    h.add("liza", "123");
    ASSERT_EQ(21, h.bucketCount());
}

TEST(TestHashMap, testLoadFactor){
    HashMap h;
    ASSERT_EQ(0, h.loadFactor());

    h.add("thomas", "123");
    ASSERT_EQ(0.1, h.loadFactor());

    h.add("ryan", "234");
    ASSERT_EQ(0.2, h.loadFactor());

    h.remove("thomas");
    ASSERT_EQ(0.1, h.loadFactor());
}

TEST(TestHashMap, testReHash){
    HashMap h;
    h.add("tyrone", "123");
    h.add("john", "234");
    h.add("jaime", "345");
    h.add("james", "123");
    h.add("kevin", "132");
    h.add("derrick", "567");
    h.add("hai", "789");
    
    ASSERT_EQ(0.7, h.loadFactor());

    h.add("leon", "098");
    ASSERT_NE(0.8, h.loadFactor());
}
