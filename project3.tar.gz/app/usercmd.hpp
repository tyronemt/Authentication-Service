#ifndef USERCMD_HPP
#define USERCMD_HPP

#include "HashMap.hpp"

class userCmd{
public:
	std::string user_command;
	std::string username;
	std::string password;
	void get_input();
};

void create(HashMap& hashmap, const std::string& username, const std::string& password);

void login(HashMap& hashmap, const std::string& username, const std::string& password);

void remove(HashMap& hashmap, const std::string& username);

void clear(HashMap& hashmap);


#endif