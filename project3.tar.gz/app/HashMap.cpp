#include "HashMap.hpp"

unsigned int default_hash(const std::string& key){
	unsigned int sum = 0;
	for (unsigned int i = 0; i < key.length(); i++){
		sum = sum + int(key[i]);
	}
	return sum;
}

//returns size of the hashmap

unsigned int HashMap::size() const{
	return num;
}

//return bucket count of the hashmap 

unsigned int HashMap::bucketCount() const{
	return maximum;
}

//return the size of the hashmap divided by the bucket count

double HashMap::loadFactor() const{
	double max_num = maximum;
	return num/ max_num;
}

//This function initialzie the hashmap with default settings
HashMap::HashMap()
	:hashFunction{default_hash}, arr{new Node* [INITIAL_BUCKET_COUNT]()}, num{0}, maximum{INITIAL_BUCKET_COUNT}
{
}

//This function initalizes the hashmap with a hashfunction the user wants to use

HashMap::HashMap(HashFunction hashFunction)
	:hashFunction{hashFunction}, arr{new Node* [INITIAL_BUCKET_COUNT]()}, num{0}, maximum{INITIAL_BUCKET_COUNT}
{
}

//This function initializes a hashmap from another hashmap with the same settings and data

HashMap::HashMap(const HashMap& hm)
	:hashFunction(hm.hashFunction), arr{new Node* [hm.maximum]}, num{hm.num}, maximum{hm.maximum}
{
	for (unsigned int i = 0; i < maximum; i++){
	 	Node* head = hm.arr[i];
        Node** old_head = &arr[i];
        *old_head = nullptr;

        while(head != nullptr){
        	Node* new_Node = new Node{head->key, head->value, nullptr};
        	*old_head = new_Node;
        	old_head = &new_Node->next;
        	head = head->next ;
        }
	 }
}


//This function is called on to destroy a hashmap

HashMap::~HashMap(){
	for (unsigned int i = 0; i < maximum; i++){
		Node* head = arr[i];
		while (head != nullptr){
			Node* old_head = head;
			head = head->next;
			delete old_head;
		}
	}
	delete [] arr;
}

//This is an operator overload function that makes the current hashmap the same as the desire hashmap

HashMap& HashMap::operator=(const HashMap& hm){
	if (this == &hm){
		return *this;
	}
	else{
		this->hashFunction = hm.hashFunction;
		this->num = hm.num;
		this->maximum = hm.maximum;
		Node** new_arr = new Node*[hm.maximum];

		for (unsigned int i = 0; i < maximum; i++){
	 	Node* head = hm.arr[i];
        Node** old_head = &new_arr[i];
        *old_head = nullptr;

        while(head != nullptr){
        	Node* new_Node = new Node{head->key, head->value, nullptr};
        	*old_head = new_Node;
        	old_head = &new_Node->next;
        	head = head->next ;
        }
	 }
		delete[] arr;
		arr = new_arr;
	}
	return *this;
}

//checks if the hashmap has a certain key

bool HashMap::contains(const std::string& key) const{
	unsigned int hash = hashFunction(key) % maximum;
	Node* head = arr[hash];

	while(head != nullptr){
		if (head-> key == key){
			return true;
		}
		head = head->next;
		}
	return false;
}

//This function is used to add a key and value to the hashmap

void HashMap::add(const std::string& key, const std::string& value){
	if (contains(key) == false){

		unsigned int hash = hashFunction(key) % maximum;
		Node* head = arr[hash];
		Node* old_head = nullptr;

		while (head != nullptr){
			old_head = head;
			head = head->next;
		}

		Node* new_node = new Node{key,value};
		if (old_head != nullptr){
			old_head->next = new_node;
		}
		else{
			arr[hash] = new_node;
		}
		num = num + 1;

		//rehash
		if (loadFactor() >= 0.8)
	    {
	        unsigned int old_maximum = maximum;
			maximum = old_maximum*2 + 1;
			Node** new_arr = new Node*[maximum]();

			for (unsigned int i = 0; i < old_maximum; i++){
				Node* head = arr[i];
				while (head != nullptr){
					Node* old_head = head;
					head = head->next;

					Node*& temp = new_arr[hashFunction(old_head-> key) % maximum];
					old_head -> next = temp;
					temp = old_head;
				}
			}
			delete [] arr;
			arr = new_arr;
	    }
	}
}

// This function is used to clear the hashmap but keeps the size and buckets the same

void HashMap::clear(){
	for (unsigned int i = 0; i < maximum; i++){
		Node* head = arr[i];
		while (head != nullptr){
			Node* old_head = head; 
			head = head->next;
			delete old_head;
		}
		arr[i] = nullptr;
	}
	num = 0;
}

//remove a certain key and value from the hashmap, if the key exist then returns true if the key 
//does not exist return false

bool HashMap::remove(const std::string& key){
	unsigned int hash = hashFunction(key) % maximum;
	Node* old_head = nullptr;
	Node* head = arr[hash];
	if (contains(key) == true){
		while (head != nullptr && head-> key != key){
			old_head = head;
			head = head->next;
		}
		if (head == nullptr){
			return false;
		}
		if (old_head == nullptr){
			arr[hash] = head->next;
		}
		else{
			old_head->next = head->next;
		}
		num = num - 1;
		delete head;
		return true;
	return false;
	}
	return false;
}


//returns the value of a key if it exist in the  hashmap if it does not then return ""

std::string HashMap::value(const std::string& key) const{
	if (contains(key)){
		unsigned int hash = hashFunction(key) % maximum;
		Node* head = arr[hash];
		while (head->key != key){
			head = head->next;
		}
		return head->value;
	}
	else{	
		return "";
	}
}


//returns the biggest bucket size

unsigned int HashMap::maxBucketSize() const{
	unsigned int max = 0;
	unsigned int temp;
	for(unsigned int i = 0; i< maximum; i++){
		temp = 0;
		Node* head = arr[i];
		while(head != nullptr){
			temp = temp + 1;
			head = head->next;
		}
		if (temp > max){
			max = temp;
		}
	}
	return max;
}