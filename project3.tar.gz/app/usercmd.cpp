#include "usercmd.hpp"
#include "HashMap.hpp"
#include <iostream>
#include <sstream>


// Gets the user commands, username, and password
void userCmd::get_input(){
	std::string line;
	
	std::getline(std::cin,line);

	std::istringstream input(line);

	user_command = "";
	username = "";
	password = "";

	input >> user_command >> username >> password;
}

//Called on when the user wants to create a username and password in the hashmap
void create(HashMap& hashmap, const std::string& username, const std::string& password){
	if (hashmap.contains(username)){
		std::cout << "EXISTS" << std::endl;
	}
	else{
		hashmap.add(username,password);
		std::cout << "CREATED" << std::endl;
	}
}

//Called on when the user wants to login with a username and password in the hashmap

void login(HashMap& hashmap, const std::string& username, const std::string& password){
	if(hashmap.contains(username) && password == hashmap.value(username)){
		std::cout << "SUCCEEDED" << std::endl;
	}
	else{
		std::cout << "FAILED" << std::endl;
	}
}

//Called on when the user wants to remove and username and password from the hashmap

void remove(HashMap& hashmap, const std::string& username){
	if (hashmap.contains(username)){
		hashmap.remove(username);
		std::cout<< "REMOVED" << std::endl;
	}
	else{
		std::cout << "NONEXISTENT" << std::endl;
	}
}

//Called on to clear the hashmap

void clear(HashMap& hashmap){
	hashmap.clear();
}

