#include <iostream>

#include <string>
#include "HashMap.hpp"
#include "usercmd.hpp"

// defining the global variables
HashMap hashmap;
std::string debug = "OFF";
userCmd user_input;

//Calls on desire function based on user input
int main()
{
	do {
		user_input.get_input();
		if (user_input.user_command == "CREATE" && user_input.username != "" && user_input.password != ""){
			create(hashmap,user_input.username,user_input.password);
		}
		else if (user_input.user_command == "LOGIN" && user_input.username != "" && user_input.password !=""){
			login(hashmap,user_input.username,user_input.password);
		}
		else if (user_input.user_command == "REMOVE" && user_input.username != "" && user_input.password == ""){
			remove(hashmap,user_input.username);
		}
		else if (user_input.user_command == "CLEAR" && user_input.username == "" && user_input.password == ""){
			clear(hashmap);
		}


		else if (user_input.user_command == "DEBUG" && user_input.username == "ON" && user_input.password == ""){
			if (debug == "OFF"){
				std::cout << "ON NOW" << std::endl;
				debug = "ON";
			}
			else{
				std::cout << "ON ALREADY" << std::endl;
			}
		}

		else if (user_input.user_command == "DEBUG" && user_input.username == "OFF" && user_input.password == ""){
			if (debug == "ON"){
				std::cout << "OFF NOW" << std::endl;
				debug = "OFF";
			}
			else{
				std::cout << "OFF ALREADY" << std::endl;
			}
		}

		else if (user_input.user_command == "LOGIN" && user_input.username == "COUNT" && user_input.password == ""){
			if (debug == "ON"){
				std::cout << hashmap.size() << std::endl;
			}
			else{
				std::cout << "INVALID" << std::endl;
			}
		}

		else if (user_input.user_command == "BUCKET" && user_input.username == "COUNT" && user_input.password == ""){
			if (debug == "ON"){
				std::cout << hashmap.bucketCount() << std::endl;
			}
			else{
				std::cout << "INVALID" << std::endl;
			}
		}

		else if (user_input.user_command == "LOAD" && user_input.username == "FACTOR" && user_input.password == ""){
			if (debug == "ON"){
				std::cout << hashmap.loadFactor() << std::endl;
			}
			else{
				std::cout << "INVALID" << std::endl;
			}
		}

		else if (user_input.user_command == "MAX" && user_input.username == "BUCKET" && user_input.password == "SIZE"){
			if (debug == "ON"){
				std::cout << hashmap.maxBucketSize() << std::endl;
			}
			else{
				std::cout << "INVALID" << std::endl;
			}
		}
		else if (user_input.user_command == "QUIT"){
			;
		}
		else{
			std::cout << "INVALID" << std::endl;
		}
	} 
	while(user_input.user_command != "QUIT");

	std::cout << "GOODBYE" << std::endl;

    return 0;
}

